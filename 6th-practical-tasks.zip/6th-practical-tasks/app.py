from tkinter import *
import random
import time
from Game import Game
from Coordinates import Coordinates
from Sprite import Sprite
from PlatformSprite import PlatformSprite
from PlatformSprite import MovingPlatformSprite
from StickFigureSprite import StickFigureSprite
from CollisionCheck import CollisionCheck
from DoorSprite import DoorSprite
